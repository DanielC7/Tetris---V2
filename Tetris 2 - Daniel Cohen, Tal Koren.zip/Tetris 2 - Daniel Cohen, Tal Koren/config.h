#ifndef _CONFIG_H_
#define _CONFIG_H_

//Please remove the comment from the line below in order to run the game

#define WINDOWS

#endif