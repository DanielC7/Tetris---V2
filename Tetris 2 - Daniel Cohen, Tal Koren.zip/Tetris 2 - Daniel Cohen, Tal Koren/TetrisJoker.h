#ifndef _TETRISJOKER_H_
#define _TETRISJOKER_H_
#include "TetrisObject.h"

class TetrisJoker : public TetrisObject {

public:
	void init();
};

#endif
