#ifndef _ART_H_
#define _ART_H_

void printGameOver();
void printTetris();
void printMenu();

#endif