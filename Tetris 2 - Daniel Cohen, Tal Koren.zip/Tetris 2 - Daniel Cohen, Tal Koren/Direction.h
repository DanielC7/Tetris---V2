#ifndef _DIRECTION_H_
#define _DIRECTION_H_

enum Direction { LEFT, RIGHT, DOWN, ROTATE, PUT };

#endif
