#ifndef _TETRISBOMB_H_
#define _TETRISBOMB_H_
#include "TetrisObject.h"

class TetrisBomb : public TetrisObject {

public:
	void init();

};

#endif