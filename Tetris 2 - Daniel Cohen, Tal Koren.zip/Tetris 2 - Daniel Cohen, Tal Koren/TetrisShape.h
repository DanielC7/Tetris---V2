#ifndef _TETRISSHAPE_H_
#define _TETRISSHAPE_H_

#include "TetrisObject.h"

class TetrisShape : public TetrisObject{

public:
	void init() ;
};

#endif